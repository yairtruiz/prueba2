from django.contrib import admin
#from .models import Articulos

#admin.site.register(Articulos)